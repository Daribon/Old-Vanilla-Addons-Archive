--[[
--
--	Sea.wow
--
--	WoW specific object functions
--
--	$LastChangedBy: AlexYoshi $
--	$Rev: 1142 $
--	$Date: 2005-03-22 17:20:48 +0100 (Tue, 22 Mar 2005) $
--]]

Sea.wow = {
	-- Tooltip related functions
	tooltip	= {};

	-- Item related functions
	item = {};

	-- Quest Log related functions
	questLog = {};

	-- Action related functions
	action = {};

	-- Spell related functions
	spell = {};

};

